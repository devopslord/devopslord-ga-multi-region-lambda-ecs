﻿using HotChocolate;
using HotChocolate.Resolvers;
using HotChocolate.Types;
using Svc.Extensions.Api.GraphQL.Abstractions;
using Svc.Extensions.Api.GraphQL.HotChocolate;
using Svc.Extensions.Odm.HotChocolate;
using Svc.Extensions.Service.Dto;
using Svc.T360.Ticket.Domain;
using Svc.T360.Ticket.Service.Dto;

namespace Svc.T360.Ticket.GraphQL.Queries;

[ExtendObjectType(nameof(Query))]
public class TestQuery
{
    public async Task<GraphQLResponse<IEnumerable<ProductTypeDto>>> GetProductTypesAsync(IResolverContext context,
        [Service] IQueryOperation operation, [Service] IBaseDtoService<ProductType, ProductTypeDto> svc)
        => await operation.ExecuteAsync(nameof(GetProductTypesAsync),
            async () =>
            {
                var result = await svc.GetAllAsync(context.ToObjectDefinition(GraphQLResponsePropertyNames.Content)) ??
                             Enumerable.Empty<ProductTypeDto>();
                return result;
            });
}
