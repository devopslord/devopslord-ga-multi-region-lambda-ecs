﻿namespace Svc.T360.Ticket.Domain.Models.Data;
public class ExternalSystemData
{
    public int Code { get; set; }
    public string Descriptor { get; set; } = "";
}
