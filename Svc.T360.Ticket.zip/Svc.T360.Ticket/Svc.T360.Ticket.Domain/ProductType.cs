﻿using System.ComponentModel.DataAnnotations;
using Svc.Extensions.Core.Model;

namespace Svc.T360.Ticket.Domain;
public class ProductType : IModel
{
    [Key]
    public long ProductTypeId { get; set; }
    public string ProductTypeExtId { get; set; } = "";
    public string ProductTypeName { get; set; } = "";
}
