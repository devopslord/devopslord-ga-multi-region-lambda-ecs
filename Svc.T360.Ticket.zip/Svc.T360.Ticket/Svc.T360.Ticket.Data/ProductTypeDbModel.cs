﻿using Svc.Extensions.Db.Data.Abstractions;
using Svc.Extensions.Db.Data.Abstractions.Attributes;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Svc.T360.Ticket.Data;

[Table("product_types")]
internal class ProductTypeDbModel : IDbModel
{
    [Key]
    public long ProductTypeId { get; set; }
    [StringKey]
    public string ProductTypeExtId { get; set; } = "";
    public string ProductTypeName { get; set; } = "";
}
