﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Svc.T360.Ticket.Service.Abstractions;
internal class IExternalSystemService
{
}
