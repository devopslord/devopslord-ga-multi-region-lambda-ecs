﻿using Svc.Extensions.Service.Dto;
using Svc.T360.Ticket.Domain;

namespace Svc.T360.Ticket.Service.Dto;
public class ProductTypeDto : IDtoModel<ProductType>
{
    public long ProductTypeId { get; set; }
    public string ProductTypeExtId { get; set; } = "";
    public string ProductTypeName { get; set; } = "";
}
