﻿using Riok.Mapperly.Abstractions;
using Svc.Extensions.Service.Dto;
using Svc.T360.Ticket.Domain;

namespace Svc.T360.Ticket.Service.Dto;

[Mapper]
public partial class ProductTypeMapper : IMapper<ProductType, ProductTypeDto>
{
    public static partial ProductTypeDto ToDto(ProductType source);
    public static partial ProductType ToModel(ProductTypeDto source);
}
